/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cvmohammadmujtaba;

/**
 *
 * @author Mohammadi
 */
public class Cvmohammadmujtaba {
 

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
         System.out.println("name:Mohammad Mujtaba Mohammadi");
         System.out.println("Father name:Abdull Ghias");
         System.out.println("From Takhar province");
         System.out.println("Education:");
         System.out.println("Omer Farooq High School");
         System.out.println("Graduated year 2023");
         System.out.println("Skills and abilities:");
         System.out.println("Office Program");
         System.out.println("Typing Skills");
         System.out.println("High Ability in mathematics");
         
         
        // TODO code applicaion logic here
    }
    
}
