package phonenumber;

import java.util.Scanner;

public class PhoneNumber {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        System.out.println("Please, enter your number");
        String number = input.next();

        if (number.startsWith("07") || number.startsWith("+93") || number.startsWith("0093")) {

            if ((number.startsWith("00937"))) {

                if (number.length() == 13) {

                    if (number.startsWith("009370")) {

                        System.out.println("Your number is from AWCC comany.");
                    } else if (number.startsWith("009379")) {

                        System.out.println("Your number is from Roshan company.");
                    } else if (number.startsWith("009376") || number.startsWith("009377")) {

                        System.out.println("Your number is from MTN company.");
                    } else if (number.startsWith("009378")) {

                        System.out.println("Your number is from Etisalat company.");
                    } else if (number.startsWith("009374")) {

                        System.out.println("Your number is from Salam company.");
                    }
                } else {
                    System.out.println("You number is incorrect, please enter again");
                }

            }

            if (number.startsWith("+937")) {

                if (number.length() == 12) {

                    if (number.startsWith("+9370")) {

                        System.out.println("Your number is from AWCC comany.");
                    } else if (number.startsWith("+9379")) {

                        System.out.println("Your number is from Roshan company.");
                    } else if (number.startsWith("+9376") || number.startsWith("+9377")) {

                        System.out.println("Your number is from MTN company.");
                    } else if (number.startsWith("+9378")) {

                        System.out.println("Your number is from Etisalat company.");
                    } else if (number.startsWith("+9374")) {

                        System.out.println("Your number is from Salam company.");
                    }
                } else {
                    System.out.println("You number is incorrect, please enter again");
                }
            }
            if (number.startsWith("07")) {

                if (number.length() == 10) {

                    if (number.startsWith("070")) {

                        System.out.println("Your number is from AWCC comany.");
                    } else if (number.startsWith("079")) {

                        System.out.println("Your number is from Roshan company.");
                    } else if (number.startsWith("076") || number.startsWith("077")) {

                        System.out.println("Your number is from MTN company.");
                    } else if (number.startsWith("078")) {

                        System.out.println("Your number is from Etisalat company.");
                    } else if (number.startsWith("074")) {

                        System.out.println("Your number is from Salam company.");
                    }
                } else {
                    System.out.println("You number is incorrect, please enter again");
                }
            }

        } else {

            System.out.println("You number is incorrect, please enter again");
        }
    }

}
