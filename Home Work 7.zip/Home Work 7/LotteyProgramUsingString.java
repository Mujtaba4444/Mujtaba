
package lotteyprogramusingstring;

import java.util.Scanner;


public class LotteyProgramUsingString {

    
    public static void main(String[] args) {
       
        Scanner input = new Scanner(System.in);
        
        int random1 = (int) (Math.random() * 10);
        int random2 = (int) (Math.random() * 10);  
        
        String random = random1 + "" + random2 ;
        
        
        System.out.println("Enter number1 for the Lottery");
        String number1 = input.nextLine();
        System.out.println("Enter number2 for the Lottery");
        String number2 = input.nextLine();
        String number3 = number1 + number2;
        
        if (random.charAt(0) == number3.charAt(0) && random.charAt(1) == number3.charAt(1))
        {
            System.out.println("You won $10000");
        }else if (random.charAt(0) == number3.charAt(1) && random.charAt(1) == number3.charAt(0))
        {
            System.out.println("You won $3000");
        }else if (random.charAt(0) == number3.charAt(0) || random.charAt(1) == number3.charAt(1) || random.charAt(1) ==  number3.charAt(0) || random.charAt(0) == number3.charAt(1))
        {
            System.out.println("You won $1000");
        }else 
        {
            System.out.println("You didn't win, please try again.");
        }
        System.out.println(random1 + "" + random2 );
      
    }
    
}
  