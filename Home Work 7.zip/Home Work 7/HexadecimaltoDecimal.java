
package hexadecimaltodecimal;

import java.util.Scanner;


public class HexadecimaltoDecimal {

   
    public static void main(String[] args) {
        
      Scanner input = new Scanner(System.in);
      
        System.out.println("Enter the number in Hexadecimal format: ");
        
        String hexaInput = input.nextLine();
        
        int decimalValue = Integer.parseInt(hexaInput, 16);
        
        System.out.println("Number in decimal format: " + decimalValue);
        
        
        
    }
    
}
